<?php

declare(strict_types=1);

return [
    'reset'     => 'Mật khẩu mới đã được cập nhật!',
    'sent'      => 'Hướng dẫn cấp lại mật khẩu đã được gửi!',
    'throttled' => 'Vui lòng đợi trước khi thử lại.',
    'token'     => 'Mã khôi phục mật khẩu không hợp lệ.',
    'user'      => 'Không tìm thấy người dùng với địa chỉ email này.',
];
