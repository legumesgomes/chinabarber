<?php

declare(strict_types=1);

return [
    'next'     => 'Trang trước &raquo;',
    'previous' => '&laquo; Trang sau',
];
