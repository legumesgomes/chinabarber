<?php

declare(strict_types=1);

return [
    'next'     => 'Seguinte &raquo;',
    'previous' => '&laquo; Anterior',
];
