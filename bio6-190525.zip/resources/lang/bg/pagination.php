<?php

declare(strict_types=1);

return [
    'next'     => 'Напред &raquo;',
    'previous' => '&laquo; Назад',
];
