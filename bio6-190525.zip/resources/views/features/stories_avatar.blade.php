{{-- Feature: Stories (ao clicar no avatar) --}}
{{-- Controlado por: $userinfo->feature_stories_status --}}
{{-- Campos disponíveis: $userinfo->feature_stories_json (JSON array de {type: 'image/video', url: '...', duration: 5}) --}}

@if(isset($userinfo) && $userinfo->feature_stories_status && !empty($userinfo->feature_stories_json))
    {{-- Este é um placeholder. A implementação real de stories requer uma biblioteca JS/CSS robusta (ex: Storybook, InstaStories.js) --}}
    {{-- e lógica para carregar o JSON e renderizar os stories quando o avatar for clicado. --}}
    {{-- Apenas para demonstração, vamos adicionar um script que loga os dados dos stories no console. --}}
    <script>
        // document.addEventListener("DOMContentLoaded", function() {
        //     const avatarElement = document.querySelector(".profile-avatar-image"); // Ajuste o seletor do avatar
        //     if (avatarElement) {
        //         avatarElement.style.cursor = "pointer";
        //         avatarElement.addEventListener("click", function() {
        //             console.log("Dados dos Stories para o usuário {{ $userinfo->id }}:");
        //             try {
        //                 const storiesData = JSON.parse("{!! addslashes($userinfo->feature_stories_json) !!}");
        //                 console.log(storiesData);
        //                 alert("Funcionalidade de Stories ativada! Veja o console para os dados.");
        //                 // Aqui você integraria a biblioteca de stories para exibir o conteúdo.
        //             } catch (e) {
        //                 console.error("Erro ao parsear JSON dos stories:", e);
        //                 alert("Erro ao carregar dados dos stories.");
        //             }
        //         });
        //     }
        // });
    </script>
    <!-- Você precisará de uma biblioteca de Stories e CSS/JS customizado para esta funcionalidade -->
@endif

