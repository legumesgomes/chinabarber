<x-guest-layout>
    <div class="mb-4 text-sm text-gray-600">
        {{ __('messages.Test E-Mail') }}
    </div>
    <br><br>
</x-guest-layout>
