<div class='button-heading'>
    <h2>{{$link->title}}</h2>
</div>


