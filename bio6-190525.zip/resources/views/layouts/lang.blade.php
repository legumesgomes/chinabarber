<html lang="{{ config('app.locale') }}">
