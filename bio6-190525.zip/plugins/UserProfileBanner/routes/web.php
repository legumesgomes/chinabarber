<?php

use Illuminate\Support\Facades\Route;
use Plugins\UserProfileBanner\Http\Controllers\UserProfileBannerController;

// Rotas para o banner de perfil do usuário
Route::middleware(['web', 'auth'])->group(function () {
    // Rota para exibir o formulário de upload
    Route::get('/profile/banner/upload', [UserProfileBannerController::class, 'showUploadForm'])
        ->name('profile.banner.upload.form');
    
    // Rota para processar o upload do banner
    Route::post('/profile/banner/upload', [UserProfileBannerController::class, 'store'])
        ->name('profile.banner.upload.store');
    
    // Rota para remover o banner
    Route::post('/profile/banner/remove', [UserProfileBannerController::class, 'remove'])
        ->name('profile.banner.remove');
});
