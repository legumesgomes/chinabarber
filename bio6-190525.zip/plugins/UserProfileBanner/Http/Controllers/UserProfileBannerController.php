<?php

namespace Plugins\UserProfileBanner\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;

class UserProfileBannerController extends Controller
{
    public function __construct()
    {
        // Middleware para garantir que o usuário está autenticado
        $this->middleware("auth");
    }

    /**
     * Exibe o formulário para upload de um novo banner de perfil.
     */
    public function create()
    {
        // Log para diagnóstico
        Log::info('UserProfileBanner: Método create chamado');
        
        // Retorna a view diretamente, sem usar @extends ou @section
        return view("userprofilebanner::upload_form_direct");
    }

    /**
     * Armazena um banner de perfil recém-enviado.
     */
    public function store(Request $request)
    {
        $request->validate([
            "banner_image" => "required|image|mimes:jpeg,png,jpg,gif,webp|max:2048", // Max 2MB
        ]);

        $user = Auth::user();

        // Exclui o banner antigo se existir
        if ($user->profile_banner_path && Storage::disk("public")->exists($user->profile_banner_path)) {
            Storage::disk("public")->delete($user->profile_banner_path);
        }

        $image = $request->file("banner_image");
        $filename = uniqid("banner_", true) . "." . $image->getClientOriginalExtension();
        
        // Armazena em public/storage/profile_banners
        // Certifique-se de ter executado `php artisan storage:link`
        $path = $image->storeAs("profile_banners", $filename, "public");

        $user->profile_banner_path = $path;
        $user->save();

        return back()->with("success", "Banner do perfil atualizado com sucesso!");
    }

    /**
     * Remove o banner do perfil.
     */
    public function destroy()
    {
        $user = Auth::user();

        if ($user->profile_banner_path) {
            if (Storage::disk("public")->exists($user->profile_banner_path)) {
                Storage::disk("public")->delete($user->profile_banner_path);
            }
            $user->profile_banner_path = null;
            $user->save();
            return back()->with("success", "Banner do perfil removido com sucesso!");
        }

        return back()->with("error", "Nenhum banner para remover.");
    }
}
