<?php

namespace App\Providers;

use Illuminate\Support\Facades\Validator;
use Illuminate\Support\ServiceProvider;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Log;
use App\Services\PluginManagerService;
use Illuminate\Support\Facades\Schema;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        // Registrar o UserProfileBannerServiceProvider diretamente aqui
        // para garantir que ele seja processado antes do boot, se possível,
        // ou pelo menos que sua classe seja conhecida.
        // CORRIGIDO: Namespace para 'plugins' minúsculo
        if (class_exists(\plugins\UserProfileBanner\Providers\UserProfileBannerServiceProvider::class)) {
            $this->app->register(\plugins\UserProfileBanner\Providers\UserProfileBannerServiceProvider::class);
            Log::info("UserProfileBannerServiceProvider (plugins minúsculo) registrado no método register() do AppServiceProvider.");
        } else {
            Log::warning("UserProfileBannerServiceProvider (plugins minúsculo) NÃO encontrado no método register() do AppServiceProvider.");
        }
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot(PluginManagerService $pluginManager)
    {
        Log::info("AppServiceProvider boot method reached.");

        // Tenta registrar o UserProfileBannerServiceProvider explicitamente no boot também,
        // caso o registro no método register() não seja suficiente ou adequado para todos os casos.
        // Isso garante que as views e rotas do plugin sejam carregadas.
        // CORRIGIDO: Namespace para 'plugins' minúsculo
        if (class_exists(\plugins\UserProfileBanner\Providers\UserProfileBannerServiceProvider::class)) {
            if (! $this->app->resolved(\plugins\UserProfileBanner\Providers\UserProfileBannerServiceProvider::class)) {
                 $this->app->register(\plugins\UserProfileBanner\Providers\UserProfileBannerServiceProvider::class);
                 Log::info("UserProfileBannerServiceProvider (plugins minúsculo) registrado explicitamente no método boot() do AppServiceProvider.");
            } else {
                 Log::info("UserProfileBannerServiceProvider (plugins minúsculo) já estava registrado/resolvido antes do registro explícito no boot().");
            }
        } else {
            Log::error("UserProfileBannerServiceProvider (plugins minúsculo) CLASS DOES NOT EXIST no momento do boot do AppServiceProvider.");
        }

        Paginator::useBootstrap();
        Validator::extend("isunique", function ($attribute, $value, $parameters, $validator) {
            $value = strtolower($value);
            $query = DB::table($parameters[0])->whereRaw("LOWER({$attribute}) = ?", [$value]);

            if (isset($parameters[1])) {
                $query->where($parameters[1], "!=", $parameters[2]);
            }

            return $query->count() === 0;
        });
        Validator::extend("exturl", function ($attribute, $value, $parameters, $validator) {
            $allowed_schemes = ["http", "https", "mailto", "tel"];
            return in_array(parse_url($value, PHP_URL_SCHEME), $allowed_schemes, true);
        });
        View::addNamespace("blocks", base_path("blocks"));

        // Lógica de carregamento dinâmico de outros plugins
        try {
            if (Schema::hasTable("plugins")) {
                $activePluginProviders = $pluginManager->getActivePluginProviders();
                Log::info("AppServiceProvider: Provedores de plugins ativos recebidos do PluginManagerService: " . print_r($activePluginProviders, true));

                foreach ($activePluginProviders as $providerClass) {
                    // CORRIGIDO: Comparação com namespace 'plugins' minúsculo
                    if ($providerClass === \plugins\UserProfileBanner\Providers\UserProfileBannerServiceProvider::class) {
                        Log::info("UserProfileBannerServiceProvider (plugins minúsculo) já tratado/registrado, pulando na lista de plugins ativos.");
                        continue;
                    }
                    
                    // Adiciona log para verificar o providerClass exato antes de class_exists
                    Log::info("AppServiceProvider: Verificando provider dinâmico: {$providerClass}");

                    if (class_exists($providerClass)) {
                        if (! $this->app->resolved($providerClass)){
                            $this->app->register($providerClass);
                            Log::info("Plugin Service Provider dinâmico registrado: {$providerClass}");
                        }
                    } else {
                        Log::warning("Classe do Service Provider do plugin dinâmico NÃO encontrada: {$providerClass}");
                    }
                }
            } else {
                Log::warning("A tabela \"plugins\" não existe. Nenhum plugin dinâmico será carregado. Execute as migrações.");
            }
        } catch (\Exception $e) {
            Log::error("Erro ao carregar providers de plugins dinâmicos no AppServiceProvider@boot: " . $e->getMessage());
        }
    }
}

